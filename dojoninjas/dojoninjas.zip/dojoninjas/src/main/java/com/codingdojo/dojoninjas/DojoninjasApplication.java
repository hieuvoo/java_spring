package com.codingdojo.dojoninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoninjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoninjasApplication.class, args);
	}
}

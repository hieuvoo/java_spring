package com.codingdojo.grouplanguages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrouplanguagesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrouplanguagesApplication.class, args);
	}
}

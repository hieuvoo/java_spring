package com.codingdojo.productsandcategories;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsandcategoriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsandcategoriesApplication.class, args);
	}
}
